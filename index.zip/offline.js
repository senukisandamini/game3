﻿{
	"version": 1629445052,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-3.4.1.min.js",
		"offlineClient.js",
		"images/photo1569982175971d92b01cf-sheet0.png",
		"images/pngclipartsoapbubblepurpleandyellowbubblessoapbubblebubblethumbnailremovebgpreview-sheet0.png",
		"images/particles.png",
		"images/particles2.png",
		"images/sprite-sheet0.png",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png"
	]
}